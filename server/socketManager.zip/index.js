// const app = require("./app");
// const server = require("./httpServer");
// const socketIo = require("socket.io");
// const socketManager = require("./socketManager/socketManager");
// const port = process.env.PORT;

// const io = socketIo(server, {
//   cors: {
//     origin: "*", // Allow frontend server
//     methods: [ "GET", "POST" ],
//   },
//   path: "/api/socket.io", // Specify the path for Socket.io
// });

// io.on('connection', (socket) =>
// {


//   // You can set up your event listeners here, for example:
//   socket.on('sendMessage', (data) =>
//   {
//     // Broadcast message or handle logic
//     socket.emit('receiveMessage', data);
//     console.log(data)
//   });

//   socket.on('disconnect', () =>
//   {
//     console.log('User disconnected');
//   });
// });

// app.use((req, res, next) =>
// {
//   req.io = io;
//   next();
// });
// socketManager.init(io);



// /* establish server port */
// server.listen(port, () =>
// {
//   console.log(`Server is running on port ${ port }.`);
// });

const app = require("./app");
const server = require("./httpServer");
const socketIo = require("socket.io");
const socketManager = require("./socketManager/socketManager");
const port = process.env.PORT;

const io = socketIo(server, {
  cors: {
    origin: "*", // Allow frontend server
    methods: [ "GET", "POST" ],
  },
  path: "/api/socket.io", // Specify the path for Socket.IO
});

// Maintain a list of online users
const onlineUsers = {};

io.on("connection", (socket) =>
{
  // console.log("A user connected:", socket.id);

  // Handle user registration
  socket.on("register", (userId) =>
  {
    onlineUsers[ userId ] = socket.id; // Map userId to socket.id
    console.log(`User registered: ${ userId } with socket ID: ${ socket.id }`);
  });

  // Handle chat messages
  socket.on("sendMessage", (data) =>
  {
    const { recipientId, message } = data;

    // Emit message to the recipient if they're online
    if (onlineUsers[ recipientId ])
    {
      io.to(onlineUsers[ recipientId ]).emit("receiveMessage", data);
    } else
    {
      console.log(`Recipient ${ recipientId } is offline`);
    }

    console.log("Message data:", data);
  });

  // Handle video call initiation
  socket.on("video-call", ({ callerId, recipientId, channel }) =>
  {
    console.log(`Video call initiated by ${ callerId } to ${ recipientId } on channel ${ channel }`);

    // Notify the recipient of the incoming call
    if (onlineUsers[ recipientId ])
    {
      io.to(onlineUsers[ recipientId ]).emit("incoming-call", { callerId, channel });
    } else
    {
      console.log(`Recipient ${ recipientId } is offline`);
    }
  });

  // Handle user disconnection
  socket.on("disconnect", () =>
  {
    console.log(`User disconnected: ${ socket.id }`);
    // Remove the disconnected user from the online users list
    for (const [ userId, socketId ] of Object.entries(onlineUsers))
    {
      if (socketId === socket.id)
      {
        delete onlineUsers[ userId ];
        console.log(`User ${ userId } removed from online users`);
        break;
      }
    }
  });
});

// Attach Socket.IO to the request object for backend use
app.use((req, res, next) =>
{
  req.io = io;
  next();
});

// Initialize custom socket managers (if any)
socketManager.init(io);

// Start the server
server.listen(port, () =>
{
  console.log(`Server is running on port ${ port }.`);
});
